/*
** my_strlen.c for strlen in /home/soumph_s/listweek3
** 
** Made by sirininh soumpholphakdy
** Login   <soumph_s@epitech.net>
** 
** Started on  Fri Oct 24 10:05:12 2014 sirininh soumpholphakdy
** Last update Sat Nov  1 15:30:53 2014 sirininh soumpholphakdy
*/

int	my_strlen(char *str)
{
  int	i;

  i = 0;
  while (str[i]);
  {
    i++;
  }
  return (1);
}
