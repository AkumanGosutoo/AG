/*
** my_isneg.c for my_isneg in /home/soumph_s/Piscine_C_J03
** 
** Made by sirininh soumpholphakdy
** Login   <soumph_s@epitech.net>
** 
** Started on  Tue Oct 28 12:34:58 2014 sirininh soumpholphakdy
** Last update Sat Nov  1 15:28:44 2014 sirininh soumpholphakdy
*/

int	my_isneg(int n)
{
  if (n > 0)
    {
      my_putchar('P');
    }
  else
    {
      my_putchar('N');
    }
  return (0);
}
