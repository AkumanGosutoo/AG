/*
** my_strncpy.c for my_strncpy in /home/soumph_s/Piscine_Blanche/Jour6
** 
** Made by sirininh soumpholphakdy
** Login   <soumph_s@epitech.net>
** 
** Started on  Fri Oct 31 22:43:56 2014 sirininh soumpholphakdy
** Last update Sat Nov  1 10:48:50 2014 sirininh soumpholphakdy
*/

char	*my_strncpy(char *dest, char *src, int n)
{
  int	i;

  i = 0;
  while (src[i] && i < n)
    {
      dest[i] = src[i];
      i++;
    }
  dest[i] = '\0';
  return (dest);
}
