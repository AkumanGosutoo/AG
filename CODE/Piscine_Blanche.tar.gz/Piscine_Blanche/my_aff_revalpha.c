/*
** my_aff_revalpha.c for my_aff_revalpha in /home/soumph_s
** 
** Made by sirininh soumpholphakdy
** Login   <soumph_s@epitech.net>
** 
** Started on  Wed Oct  1 16:25:41 2014 sirininh soumpholphakdy
** Last update Sat Nov  1 15:27:51 2014 sirininh soumpholphakdy
*/

int	my_aff_revalpha()
{
  char c;

  c = 122;
  while (c > 96)
    {
      my_putchar(c);
      c = c - 1;
    }
  return 0;
}
