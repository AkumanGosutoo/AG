/*
** my_aff_chiffre.c for my_aff_chiffre in /home/soumph_s
** 
** Made by sirininh soumpholphakdy
** Login   <soumph_s@epitech.net>
** 
** Started on  Wed Oct  1 16:39:53 2014 sirininh soumpholphakdy
** Last update Sat Nov  1 15:28:14 2014 sirininh soumpholphakdy
*/

int	my_aff_chiffre()
{
  char	c;

  c = 48 ;
  while (c < 58)
    {
      my_putchar(c);
      c = c + 1;
    }
  return (0);
}
