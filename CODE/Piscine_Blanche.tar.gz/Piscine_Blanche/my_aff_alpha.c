/*
** my_aff_alpha.c for my_aff_alpha in /home/soumph_s
** 
** Made by sirininh soumpholphakdy
** Login   <soumph_s@epitech.net>
** 
** Started on  Wed Oct  1 12:08:11 2014 sirininh soumpholphakdy
** Last update Sat Nov  1 15:27:33 2014 sirininh soumpholphakdy
*/

int	my_aff_alpha()
{
  char c;

  c = 97;
  while (c < 123)
    {
      my_putchar(c);
      c++;
    }
}
