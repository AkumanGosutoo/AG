/*
** my_swap.c for my_swap in /home/soumph_s/Piscine_Blanche
** 
** Made by sirininh soumpholphakdy
** Login   <soumph_s@epitech.net>
** 
** Started on  Tue Oct 28 15:52:25 2014 sirininh soumpholphakdy
** Last update Sat Nov  1 15:31:09 2014 sirininh soumpholphakdy
*/

int	my_swap(int *a, int *b)
{
  int	d;

  d = *a;
  *a = *b;
  *b = d;
}
