/*
** lem_in.h for  in /home/chopar_a/rendu/CPE_2014_lemin
** 
** Made by adrien chopard
** Login   <chopar_a@epitech.net>
** 
** Started on  Fri Apr 17 15:40:13 2015 adrien chopard
** Last update Fri Apr 17 15:51:01 2015 adrien chopard
*/

#ifndef SERVER_H_
# define SERVER_H_

void	my_putchar(char c);
void	my_putstr(char *str);
int	my_strlen(char *str);
int	my_putnbr(int nb);
int	test();

#endif /* !SERVER_H_ */
