/*
** get_next_line.h for  in /home/chopar_a/rendu/CPE_2014_lemin
** 
** Made by adrien chopard
** Login   <chopar_a@epitech.net>
** 
** Started on  Mon Apr 20 17:27:43 2015 adrien chopard
** Last update Mon Apr 20 17:27:49 2015 adrien chopard
*/

#ifndef __GET_NEXT_LINE_H__
#define __GET_NEXT_LINE_H__

#define SIZE 5000
#define MALLOC_ERROR 0

char    *get_next_line(const int fd);

#endif /* __GET_NEXT_LINE_H__ */
