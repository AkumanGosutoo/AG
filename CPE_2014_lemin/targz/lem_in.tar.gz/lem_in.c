/*
** lem_in.c for  in /home/chopar_a/rendu/CPE_2014_lemin
** 
** Made by adrien chopard
** Login   <chopar_a@epitech.net>
** 
** Started on  Fri Apr 17 15:38:31 2015 adrien chopard
** Last update Mon Apr 20 17:28:43 2015 adrien chopard
*/

#include <unistd.h>
#include "lem_in.h"

int	test()
{
  my_putchar('a');
  return (0);
}


