/*
** main.c for  in /home/chopar_a/rendu/CPE_2014_lemin
** 
** Made by adrien chopard
** Login   <chopar_a@epitech.net>
** 
** Started on  Mon Apr 20 17:22:36 2015 adrien chopard
** Last update Mon Apr 20 17:34:43 2015 adrien chopard
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "lem_in.h"
#include "get_next_line.h"

char    *get_next_line(const int fd)
{
  /*static char   buffer;*/
  char		*str;

  str = malloc(sizeof(char) * (SIZE + 1));
  if (str ==  MALLOC_ERROR)
    return (NULL);
  if (read(fd, str, SIZE))
    return (0);
  else
    return (NULL);
}

int	main(int argc, char **argv)
{
  int   fd;
  char  *s;

  fd = open(argv[1] ,O_RDONLY);
  if (fd == -1)
    {
      my_putstr("ERROR");
      return (1);
    }
  else if (argc > 3)
    my_putstr("ERROR");
  while ((s = get_next_line(fd)))
    {
      my_putstr(s);
      my_putchar('\n');
      free(s);
    }
  close(fd);
  return (0);
}
